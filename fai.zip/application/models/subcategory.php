<?php
require_once ('..\libraries\datamapper.php');

//namespace fai\models;


/**
 * @author akil
 * @version 1.0
 * @created 06-Jul-2015 12:01:22 PM
 */
class SubCategory extends DataMapper
{

	function __construct()
	{
	}

	function __destruct()
	{
	}



}
?>