<?php
//require_once ('..\libraries\datamapper.php');

//namespace fai\models;


/**
 * @author akil
 * @version 1.0
 * @created 06-Jul-2015 12:01:43 PM
 */
class StaticPage extends DataMapper
{

	var $table = 'static_pages';



}
?>