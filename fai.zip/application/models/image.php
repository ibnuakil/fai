<?php
require_once ('..\libraries\datamapper.php');

namespace fai\models;


/**
 * @author akil
 * @version 1.0
 * @created 06-Jul-2015 12:01:26 PM
 */
class Image extends DataMapper
{

	function __construct()
	{
	}

	function __destruct()
	{
	}



}
?>