<div class="row">
    <div class="col-xs-12">
        <div class="page-header">
            <h2><?=$page->menu_name ?></h2>
            <hr>
            <p><?=$page->content ?></p>
        </div>
    </div>
</div>