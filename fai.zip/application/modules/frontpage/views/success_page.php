<div class="row">
    <div class="col-xs-12">
                <h2>Thanks For Join Us</h2>
                
                <h3><?=$first_name.' '.$last_name?></h3>
                <p></p>

    </div>
</div>

