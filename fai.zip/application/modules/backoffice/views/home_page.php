<div class="fluid">
				
<div class="widget grid12">
        <div class="widget-header">
            <h2 class="page-title">
                    <i class="fa fa-th"></i>Welcome<span><?=$this->session->userdata('session_name')?></span>
            </h2>
                
        </div> <!-- /widget-header -->
        <div class="widget-content">
                <p>
                    Anda berada di laman administrasi situs FAI.
                </p>

        </div> <!-- /widget-content -->

</div> <!-- /widget -->

</div> <!-- /fluid -->