<?php


//namespace fai\modules\backoffice;


/**
 * @author akil
 * @version 1.0
 * @created 05-Aug-2015 3:38:43 PM
 */
interface IControl
{

	public function add();

	public function edit();

	public function find();

	public function index();

	public function remove();

	public function save();

}
?>